#ifndef __BEEP_H_
#define __BEEP_H_

#define BEEP PAout(0)

#define BEEP_OFF 0
#define BEEP_ON 1




void BEEP_Init(void);


#endif
